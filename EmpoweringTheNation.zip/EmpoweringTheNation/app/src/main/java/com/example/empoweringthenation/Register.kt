package com.example.registrationapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.empoweringthenation.R

class Register : AppCompatActivity() {

    private lateinit var usernameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var genderSpinner: Spinner
    private lateinit var nationalityEditText: EditText
    private lateinit var courseSpinner: Spinner
    private lateinit var registerButton: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        usernameEditText = findViewById(R.id.usernameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        ageEditText = findViewById(R.id.ageEditText)
        genderSpinner = findViewById(R.id.genderSpinner)
        nationalityEditText = findViewById(R.id.nationalityEditText)
        courseSpinner = findViewById(R.id.courseSpinner)
        registerButton = findViewById(R.id.registerButton)

        // Set up the course spinner
        val courses = arrayOf("Select a Course", "First Aid", "Sewing", "Landscaping", "Life Skills", "Child Minding", "Cooking", "Garden Maintenance")
        val courseAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, courses)
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        courseSpinner.adapter = courseAdapter

        // Set up the gender spinner
        val genders = arrayOf("Select Gender", "Male", "Female", "Other")
        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genders)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genderSpinner.adapter = genderAdapter

        // Set click listener on register button
        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            val age = ageEditText.text.toString()
            val selectedGender = genderSpinner.selectedItem.toString()
            val nationality = nationalityEditText.text.toString()
            val selectedCourse = courseSpinner.selectedItem.toString()

            if (username.isNotBlank() && email.isNotBlank() && password.isNotBlank() &&
                age.isNotBlank() && selectedGender != "Select Gender" &&
                nationality.isNotBlank() && selectedCourse != "Select a Course") {

                Toast.makeText(this, "Registration Successful for $selectedCourse!", Toast.LENGTH_SHORT).show()
                // Here, add code to handle registration, like saving to database or navigating to another screen
            } else {
                Toast.makeText(this, "Please fill in all fields and select valid options", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
